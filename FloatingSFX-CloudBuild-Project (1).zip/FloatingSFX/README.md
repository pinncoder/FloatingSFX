# Floating SFX (Android prototype)

Native Android Java prototype for a draggable floating bubble and customizable soundboard.

## Features
- Floating overlay bubble (requires Android's "Display over other apps" permission)
- Expandable SFX panel
- Add a custom sound by naming it and selecting an audio file from Android's document picker
- Plays imported audio from the overlay
- Foreground notification while overlay is running

## Build APK
1. Install Android Studio (recent version) and Android SDK Platform 35.
2. Open this folder as a project in Android Studio.
3. Allow Gradle sync and install any requested SDK components.
4. Choose Build > Build Bundle(s) / APK(s) > Build APK(s).
5. APK output is usually `app/build/outputs/apk/debug/app-debug.apk`.

## Important limitations
- This is an initial prototype; test on your specific Android version/device.
- Android may restrict overlay/foreground service behavior; the user must grant overlay permission.
- Playing SFX over other apps does not guarantee that the sound is captured into another app's recording or sent through a call.
- Android 13+ may request notification permission depending on OS behavior.

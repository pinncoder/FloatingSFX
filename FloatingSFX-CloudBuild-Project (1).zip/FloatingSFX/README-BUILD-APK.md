# Build APK tanpa PC sendiri (pakai GitHub Actions)

File ZIP ini berisi source project, bukan APK siap instal. Workflow `.github/workflows/build-apk.yml` bisa membangun APK di cloud GitHub Actions.

1. Buat akun / login di GitHub.
2. Buat repository baru, misalnya `FloatingSFX`.
3. Upload semua isi folder `FloatingSFX` ke repository (termasuk folder `.github`).
4. Buka tab **Actions** pada repository dan pilih workflow **Build Floating SFX APK**.
5. Tekan **Run workflow** jika belum berjalan otomatis.
6. Setelah workflow selesai dengan status hijau, buka hasil run dan bagian **Artifacts**.
7. Download `FloatingSFX-debug-apk.zip`, ekstrak, lalu install `app-debug.apk` di HP Android. Jika diminta, izinkan pemasangan dari sumber tersebut.

APK ini adalah debug build untuk uji coba pribadi, bukan rilisan Play Store. Android mungkin menampilkan peringatan saat instalasi karena APK belum didistribusikan melalui Play Store.

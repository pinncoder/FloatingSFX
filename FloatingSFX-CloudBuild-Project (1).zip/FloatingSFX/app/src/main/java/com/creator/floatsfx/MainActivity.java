package com.creator.floatsfx;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.content.SharedPreferences;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Map;

public class MainActivity extends Activity {
    private static final int PICK_AUDIO = 101;
    private SharedPreferences prefs;
    private String pendingLabel = "Custom SFX";

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        prefs = getSharedPreferences("sfx", MODE_PRIVATE);
        buildUi();
    }

    private int dp(float v) { return (int)(v * getResources().getDisplayMetrics().density); }
    private TextView text(String s, int size) {
        TextView t = new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(0xFFF4F3FF); t.setPadding(dp(4),dp(8),dp(4),dp(8)); return t;
    }
    private Button button(String s) {
        Button b = new Button(this); b.setText(s); b.setAllCaps(false); b.setTextColor(0xFFFFFFFF); b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(0xFF6544D8)); return b;
    }
    private void buildUi() {
        LinearLayout root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(dp(20),dp(24),dp(20),dp(20)); root.setBackgroundColor(0xFF0B1020);
        root.addView(text("◉ FLOATING SFX", 26));
        root.addView(text("Soundboard mengambang untuk konten gaming", 14));
        root.addView(text("1. Izinkan tampil di atas aplikasi lain.\n2. Jalankan bubble.\n3. Ketuk bubble untuk membuka tombol SFX.", 15));
        Button overlay = button("Izinkan Floating Overlay");
        overlay.setOnClickListener(v -> { if (Build.VERSION.SDK_INT >= 23 && !Settings.canDrawOverlays(this)) startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:"+getPackageName()))); else Toast.makeText(this,"Izin overlay sudah aktif",Toast.LENGTH_SHORT).show(); });
        root.addView(overlay, new LinearLayout.LayoutParams(-1, -2));
        Button start = button("Mulai Floating SFX");
        start.setOnClickListener(v -> { if (Build.VERSION.SDK_INT >= 23 && !Settings.canDrawOverlays(this)) { Toast.makeText(this,"Aktifkan izin overlay dulu",Toast.LENGTH_LONG).show(); return; } Intent i = new Intent(this,FloatingService.class); if (Build.VERSION.SDK_INT >= 26) startForegroundService(i); else startService(i); Toast.makeText(this,"Bubble SFX aktif",Toast.LENGTH_SHORT).show(); });
        root.addView(start, new LinearLayout.LayoutParams(-1, -2));
        Button add = button("＋ Tambah tombol SFX custom"); add.setOnClickListener(v -> addCustom()); root.addView(add, new LinearLayout.LayoutParams(-1,-2));
        Button stop = button("Matikan Floating SFX"); stop.setOnClickListener(v -> { stopService(new Intent(this,FloatingService.class)); Toast.makeText(this,"Floating SFX dimatikan",Toast.LENGTH_SHORT).show(); }); root.addView(stop,new LinearLayout.LayoutParams(-1,-2));
        root.addView(text("Tombol tersimpan",18));
        LinearLayout list = new LinearLayout(this); list.setOrientation(LinearLayout.VERTICAL);
        Map<String,?> all = prefs.getAll();
        for (String key : all.keySet()) if (key.startsWith("label_")) list.addView(text("• " + all.get(key),14));
        if (list.getChildCount()==0) list.addView(text("Belum ada tombol custom. Tambahkan file audio milikmu.",14));
        root.addView(list);
        setContentView(root);
    }
    private void addCustom() {
        EditText input = new EditText(this); input.setSingleLine(true); input.setHint("Nama tombol, mis. Victory");
        new AlertDialog.Builder(this).setTitle("Buat tombol SFX").setView(input).setNegativeButton("Batal",null).setPositiveButton("Pilih audio",(d,w)->{
            pendingLabel = input.getText().toString().trim(); if (pendingLabel.isEmpty()) pendingLabel="Custom SFX";
            Intent pick = new Intent(Intent.ACTION_OPEN_DOCUMENT); pick.addCategory(Intent.CATEGORY_OPENABLE); pick.setType("audio/*"); startActivityForResult(pick,PICK_AUDIO);
        }).show();
    }
    @Override protected void onActivityResult(int requestCode,int resultCode,Intent data) {
        super.onActivityResult(requestCode,resultCode,data);
        if(requestCode==PICK_AUDIO && resultCode==RESULT_OK && data!=null && data.getData()!=null) {
            Uri uri=data.getData(); try { getContentResolver().takePersistableUriPermission(uri,Intent.FLAG_GRANT_READ_URI_PERMISSION); } catch(Exception ignored) {}
            String id=String.valueOf(System.currentTimeMillis()); prefs.edit().putString("label_"+id,pendingLabel).putString("uri_"+id,uri.toString()).apply();
            Toast.makeText(this,"SFX ditambahkan: "+pendingLabel,Toast.LENGTH_SHORT).show(); buildUi();
        }
    }
}

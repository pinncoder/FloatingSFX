package com.creator.floatsfx;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.media.AudioAttributes;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Build;
import android.os.IBinder;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Map;

public class FloatingService extends Service {
    private WindowManager wm; private View bubble, panel; private boolean expanded=false; private int x=20,y=250;
    private final ArrayList<MediaPlayer> players = new ArrayList<>();
    private int dp(float v){return (int)(v*getResources().getDisplayMetrics().density);}
    @Override public void onCreate(){super.onCreate(); startForegroundNotice(); wm=(WindowManager)getSystemService(WINDOW_SERVICE); showBubble();}
    private void startForegroundNotice(){
        String channel="floating_sfx_channel"; if(Build.VERSION.SDK_INT>=26){NotificationChannel c=new NotificationChannel(channel,"Floating SFX",NotificationManager.IMPORTANCE_LOW); ((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(c);}
        Notification.Builder b=Build.VERSION.SDK_INT>=26?new Notification.Builder(this,channel):new Notification.Builder(this);
        b.setContentTitle("Floating SFX aktif").setContentText("Ketuk bubble untuk membuka soundboard").setSmallIcon(android.R.drawable.ic_media_play).setOngoing(true);
        startForeground(7,b.build());
    }
    private WindowManager.LayoutParams params(int w,int h){int type=Build.VERSION.SDK_INT>=26?WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY:WindowManager.LayoutParams.TYPE_PHONE; return new WindowManager.LayoutParams(w,h,type,WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT);}
    private void showBubble(){
        if(bubble!=null)return;
        TextView b=new TextView(this); b.setText("♫"); b.setTextSize(25); b.setTextColor(Color.WHITE); b.setGravity(Gravity.CENTER); b.setBackground(roundBg(0xFF7048E8,dp(28))); bubble=b;
        WindowManager.LayoutParams p=params(dp(56),dp(56)); p.gravity=Gravity.TOP|Gravity.START; p.x=x;p.y=y;
        b.setOnClickListener(v->{if(expanded)hidePanel();else showPanel();});
        b.setOnTouchListener(new View.OnTouchListener(){float sx,sy;int ox,oy;boolean moved;
            public boolean onTouch(View v,MotionEvent e){if(e.getAction()==MotionEvent.ACTION_DOWN){sx=e.getRawX();sy=e.getRawY();ox=p.x;oy=p.y;moved=false;return false;} if(e.getAction()==MotionEvent.ACTION_MOVE){float dx=e.getRawX()-sx,dy=e.getRawY()-sy;if(Math.abs(dx)>dp(5)||Math.abs(dy)>dp(5))moved=true;if(moved){p.x=ox+(int)dx;p.y=oy+(int)dy;wm.updateViewLayout(bubble,p);return true;}} if(e.getAction()==MotionEvent.ACTION_UP&&moved){x=p.x;y=p.y;return true;}return false;}});
        wm.addView(bubble,p);
    }
    private android.graphics.drawable.GradientDrawable roundBg(int color,int radius){android.graphics.drawable.GradientDrawable d=new android.graphics.drawable.GradientDrawable();d.setColor(color);d.setCornerRadius(radius);d.setStroke(dp(1),0xFF9C85FF);return d;}
    private void showPanel(){
        if(panel!=null)return; expanded=true;
        LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);box.setPadding(dp(10),dp(8),dp(10),dp(10));box.setBackground(roundBg(0xF20B1020,dp(18)));
        LinearLayout header=new LinearLayout(this);header.setGravity(Gravity.CENTER_VERTICAL);
        TextView title=new TextView(this);title.setText("  MY SFX  ");title.setTextColor(Color.WHITE);title.setTextSize(17);title.setTypeface(null,1);header.addView(title,new LinearLayout.LayoutParams(0,-2,1));
        Button add=new Button(this);add.setText("+");add.setTextSize(18);add.setMinWidth(dp(42));add.setOnClickListener(v->{hidePanel();Intent i=new Intent(this,MainActivity.class);i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);startActivity(i);Toast.makeText(this,"Tambah audio dari aplikasi Floating SFX",Toast.LENGTH_LONG).show();});header.addView(add);
        Button close=new Button(this);close.setText("×");close.setMinWidth(dp(42));close.setOnClickListener(v->hidePanel());header.addView(close);box.addView(header);
        ScrollView scroll=new ScrollView(this);LinearLayout grid=new LinearLayout(this);grid.setOrientation(LinearLayout.VERTICAL);
        SharedPreferences prefs=getSharedPreferences("sfx",MODE_PRIVATE);Map<String,?> all=prefs.getAll();ArrayList<String> ids=new ArrayList<>();for(String k:all.keySet())if(k.startsWith("label_"))ids.add(k.substring(6));Collections.sort(ids,Comparator.naturalOrder());
        if(ids.isEmpty()){TextView empty=new TextView(this);empty.setText("Belum ada SFX custom. Tekan + atau buka aplikasi untuk menambah audio.");empty.setTextColor(0xFFD7D2EA);empty.setPadding(dp(8),dp(12),dp(8),dp(12));grid.addView(empty);}
        for(String id:ids){String label=prefs.getString("label_"+id,"SFX"),uri=prefs.getString("uri_"+id,"");Button btn=new Button(this);btn.setText("▶  "+label);btn.setAllCaps(false);btn.setTextColor(Color.WHITE);btn.setBackgroundTintList(android.content.res.ColorStateList.valueOf(0xFF39266F));btn.setOnClickListener(v->play(uri,label));LinearLayout.LayoutParams bp=new LinearLayout.LayoutParams(-1,-2);bp.topMargin=dp(4);grid.addView(btn,bp);}
        scroll.addView(grid);box.addView(scroll,new LinearLayout.LayoutParams(-1,dp(210)));
        TextView hint=new TextView(this);hint.setText("Tip: suara diputar dari perangkat; masuk ke rekaman aplikasi lain tidak dijamin.");hint.setTextColor(0xFFB7B4C9);hint.setTextSize(10);hint.setPadding(dp(4),dp(6),dp(4),0);box.addView(hint);
        panel=box;WindowManager.LayoutParams p=params(dp(280),-2);p.gravity=Gravity.TOP|Gravity.START;p.x=Math.max(dp(8),x-dp(215));p.y=y+dp(60);wm.addView(panel,p);
    }
    private void play(String uri,String label){try{MediaPlayer mp=new MediaPlayer();mp.setAudioAttributes(new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build());mp.setDataSource(this,Uri.parse(uri));mp.setOnCompletionListener(m->{m.release();players.remove(m);});mp.setOnErrorListener((m,what,extra)->{m.release();players.remove(m);Toast.makeText(this,"Audio gagal diputar",Toast.LENGTH_SHORT).show();return true;});mp.prepareAsync();mp.setOnPreparedListener(MediaPlayer::start);players.add(mp);}catch(Exception e){Toast.makeText(this,"Tidak bisa membuka audio ini",Toast.LENGTH_SHORT).show();}}
    private void hidePanel(){if(panel!=null){try{wm.removeView(panel);}catch(Exception ignored){}panel=null;}expanded=false;}
    @Override public int onStartCommand(Intent i,int f,int id){return START_STICKY;}
    @Override public void onDestroy(){hidePanel();if(bubble!=null){try{wm.removeView(bubble);}catch(Exception ignored){}bubble=null;}for(MediaPlayer p:players){try{p.release();}catch(Exception ignored){}}players.clear();super.onDestroy();}
    @Override public IBinder onBind(Intent i){return null;}
}
